# Echowash — Landing Page

Landing page produk sabun cuci piring ramah lingkungan **Echowash**, dibangun dengan Next.js (App Router), Tailwind CSS, dan Framer Motion.

## Cara menjalankan

```bash
npm install
npm run dev
```

Buka `http://localhost:3000`.

## Struktur proyek

```
app/
  layout.tsx        # Root layout + font Plus Jakarta Sans + metadata SEO
  page.tsx           # Menyusun semua section
  globals.css         # Design tokens & style global
components/
  Navbar.tsx           # Nav sticky dengan efek scroll
  Hero.tsx             # Hero dengan video reveal produk
  ProblemSolution.tsx  # Masalah limbah jelantah vs solusi Echowash
  Ingredients.tsx      # Bento grid 2 bahan utama
  CircularEconomy.tsx  # Diagram orbit "signature" ekonomi sirkular
  CTA.tsx               # Ajakan membeli/bergabung
  Footer.tsx            # Footer brand
public/
  videos/hero-reveal.mp4 / .webm   # Video reveal produk (dari aset yang diunggah)
  images/product-hero.jpg          # Frame akhir video sebagai poster/fallback
  images/bg-poster.jpg              # Frame awal sebagai poster alternatif
```

## Catatan desain

- **Palet warna**: Hijau sage (`sage`), krem (`cream`), keemasan (`gold`) untuk minyak, cokelat (`lerak`) untuk buah lerak, dan teal dalam (`deep`) yang menyatu dengan video di Hero.
- **Tipografi**: Plus Jakarta Sans (sesuai arahan), dengan hierarki dibangun lewat skala, bobot (400–800), dan tracking — bukan menambah keluarga font baru.
- **Elemen signature**: Diagram orbit melingkar di section "Ekonomi Sirkular" — bentuk lingkaran tertutup (bukan garis linear 1→4) dipilih secara sengaja untuk merepresentasikan konsep sirkular itu sendiri. Di layar kecil, diagram ini berubah jadi daftar bertingkat dengan penanda "siklus berulang" di akhir.
- **Motion**: Animasi fade/slide saat scroll (`whileInView`) dipakai secukupnya, plus satu momen orkestrasi di Hero (video reveal produk) dan drawing animation pada garis orbit. Menghormati `prefers-reduced-motion`.
- **Video hero**: Dikonversi dari 154 frame yang diunggah menjadi `hero-reveal.mp4` (H.264) dan `hero-reveal.webm` (VP9) agar ringan dan didukung luas oleh browser modern. Video autoplay, muted, loop, dan punya poster fallback untuk browser yang memblokir autoplay.

## Mengganti aset

Ganti file di `public/videos/` dan `public/images/product-hero.jpg` dengan aset final Anda bila diperlukan — nama file dan path sudah dirujuk otomatis oleh `Hero.tsx`.
