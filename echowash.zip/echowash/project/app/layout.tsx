import type { Metadata } from "next";
import { Plus_Jakarta_Sans } from "next/font/google";
import "./globals.css";

const jakarta = Plus_Jakarta_Sans({
  subsets: ["latin"],
  weight: ["400", "500", "600", "700", "800"],
  variable: "--font-jakarta",
  display: "swap",
});

export const metadata: Metadata = {
  title: "Echowash — Bersih Maksimal, Rawat Bumi Kita",
  description:
    "Echowash adalah sabun cuci piring dari daur ulang minyak jelantah dan ekstrak buah lerak alami. Ampuh melawan lemak, lembut di tangan, aman kembali ke alam.",
  keywords: [
    "Echowash",
    "sabun cuci piring ramah lingkungan",
    "minyak jelantah daur ulang",
    "ekstrak lerak",
    "ekonomi sirkular",
  ],
  openGraph: {
    title: "Echowash — Bersih Maksimal, Rawat Bumi Kita",
    description:
      "Dari limbah dapur, kembali ke dapur. Sabun cuci piring alami berbasis minyak jelantah daur ulang & ekstrak lerak.",
    type: "website",
    locale: "id_ID",
  },
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="id" className={jakarta.variable}>
      <body>{children}</body>
    </html>
  );
}
