import Navbar from "@/components/Navbar";
import Hero from "@/components/Hero";
import ProblemSolution from "@/components/ProblemSolution";
import Ingredients from "@/components/Ingredients";
import CircularEconomy from "@/components/CircularEconomy";
import CTA from "@/components/CTA";
import Footer from "@/components/Footer";

export default function Home() {
  return (
    <main>
      <Navbar />
      <Hero />
      <ProblemSolution />
      <Ingredients />
      <CircularEconomy />
      <CTA />
      <Footer />
    </main>
  );
}
