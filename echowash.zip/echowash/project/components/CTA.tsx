"use client";

import { motion } from "framer-motion";
import { ArrowRight } from "lucide-react";

export default function CTA() {
  return (
    <section id="cta" className="relative overflow-hidden bg-sage-600 py-24 sm:py-28">
      {/* Aksen gelembung lembut, murni dekoratif dan tidak berlebihan */}
      <div className="pointer-events-none absolute -left-16 -top-16 h-64 w-64 rounded-full bg-cream-100/5 blur-3xl" />
      <div className="pointer-events-none absolute -bottom-20 -right-10 h-72 w-72 rounded-full bg-gold-500/10 blur-3xl" />

      <div className="relative mx-auto max-w-3xl px-6 text-center lg:px-10">
        <motion.h2
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-100px" }}
          transition={{ duration: 0.6 }}
          className="text-balance text-3xl font-extrabold tracking-tight text-cream-100 sm:text-4xl lg:text-5xl"
        >
          Setiap Kali Kamu Mencuci, Kamu Menjaga Bumi
        </motion.h2>

        <motion.p
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-100px" }}
          transition={{ duration: 0.6, delay: 0.1 }}
          className="mx-auto mt-5 max-w-xl text-lg leading-relaxed text-cream-100/85"
        >
          Bergabunglah dengan gerakan dapur sirkular. Satu botol Echowash di
          dapurmu adalah satu langkah lebih dekat pada bumi yang lebih bersih
          untuk anak cucu kita.
        </motion.p>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-100px" }}
          transition={{ duration: 0.6, delay: 0.2 }}
          className="mt-10 flex flex-wrap items-center justify-center gap-4"
        >
          <a
            href="#"
            className="group inline-flex items-center gap-2 rounded-full bg-gold-500 px-8 py-4 text-base font-bold text-deep-900 shadow-lg transition-all hover:bg-gold-300 hover:shadow-xl"
          >
            Beli Echowash Sekarang
            <ArrowRight
              size={18}
              className="transition-transform group-hover:translate-x-1"
            />
          </a>
          <a
            href="https://www.instagram.com/ecowash_id?stkn=MXd2NHl3N3U5azE2eA%3D%3D"
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-2 rounded-full border border-cream-100/30 px-8 py-4 text-base font-semibold text-cream-100 transition-colors hover:bg-cream-100/10"
          >
            Gabung Gerakan #DapurSirkular
          </a>
        </motion.div>
      </div>
    </section>
  );
}
