"use client";

import { motion } from "framer-motion";
import { Droplets, FlaskConical, PackageCheck, Sprout } from "lucide-react";

const steps = [
  {
    n: "01",
    icon: Droplets,
    title: "Limbah",
    desc: "Minyak jelantah dijemput dari dapur rumah tangga & UMKM — sebelum sempat dibuang ke saluran air.",
    // posisi di orbit desktop: atas
    pos: { top: "0%", left: "50%" },
  },
  {
    n: "02",
    icon: FlaskConical,
    title: "Diproses",
    desc: "Disaring, dimurnikan, lalu dipadukan dengan ekstrak lerak melalui proses yang ramah lingkungan.",
    pos: { top: "50%", left: "100%" },
  },
  {
    n: "03",
    icon: PackageCheck,
    title: "Produk Bermanfaat",
    desc: "Lahirlah Echowash — sabun cuci piring berbusa lembut yang ampuh mengangkat lemak.",
    pos: { top: "100%", left: "50%" },
  },
  {
    n: "04",
    icon: Sprout,
    title: "Aman Bagi Bumi",
    desc: "Terurai alami setelah dipakai, tak meracuni air — dan siklus dimulai lagi dari awal.",
    pos: { top: "50%", left: "0%" },
  },
];

export default function CircularEconomy() {
  return (
    <section
      id="sirkular"
      className="relative overflow-hidden bg-deep-900 bg-noise py-24 sm:py-32"
    >
      <div className="mx-auto max-w-7xl px-6 lg:px-10">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-100px" }}
          transition={{ duration: 0.6 }}
          className="mx-auto mb-20 max-w-2xl text-center"
        >
          <span className="text-xs font-semibold uppercase tracking-widest text-gold-300">
            Bagaimana Echowash Bekerja
          </span>
          <h2 className="text-balance mt-4 text-3xl font-extrabold tracking-tight text-cream-100 sm:text-4xl">
            Sebuah Siklus yang Tak Pernah Putus
          </h2>
          <p className="mt-4 text-cream-100/70">
            Bukan garis lurus dari produksi ke pembuangan — melainkan
            lingkaran yang terus berputar, dari dapur, kembali ke dapur.
          </p>
        </motion.div>

        {/* ORBIT — tampilan desktop */}
        <div className="relative mx-auto hidden aspect-square max-w-xl lg:block">
          {/* cincin luar berputar pelan sebagai atmosfer ambient */}
          <div className="absolute inset-6 rounded-full border border-dashed border-cream-100/10 animate-spin-slow" />

          <svg
            viewBox="0 0 400 400"
            className="absolute inset-0 h-full w-full"
            fill="none"
          >
            <motion.circle
              cx="200"
              cy="200"
              r="150"
              stroke="#C9993E"
              strokeWidth="2"
              strokeLinecap="round"
              initial={{ pathLength: 0, opacity: 0 }}
              whileInView={{ pathLength: 1, opacity: 0.6 }}
              viewport={{ once: true }}
              transition={{ duration: 1.8, ease: "easeInOut" }}
            />
          </svg>

          {/* pusat orbit */}
          <div className="absolute left-1/2 top-1/2 grid h-24 w-24 -translate-x-1/2 -translate-y-1/2 place-items-center rounded-full bg-sage-600 text-center shadow-xl">
            <span className="text-xs font-bold uppercase leading-tight tracking-wide text-cream-100">
              Ekonomi
              <br />
              Sirkular
            </span>
          </div>

          {steps.map((step, i) => (
            <motion.div
              key={step.n}
              initial={{ opacity: 0, scale: 0.7 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: 0.5 + i * 0.25 }}
              style={{ top: step.pos.top, left: step.pos.left }}
              className="absolute w-64 -translate-x-1/2 -translate-y-1/2"
            >
              <div className="flex flex-col items-center gap-3 rounded-2xl bg-cream-100/[0.06] p-5 text-center backdrop-blur-sm ring-1 ring-cream-100/10">
                <div className="grid h-11 w-11 place-items-center rounded-full bg-gold-500/15">
                  <step.icon size={20} className="text-gold-300" />
                </div>
                <div>
                  <span className="text-[11px] font-bold tracking-widest text-gold-300/80">
                    {step.n}
                  </span>
                  <h3 className="text-sm font-bold text-cream-100">
                    {step.title}
                  </h3>
                </div>
                <p className="text-xs leading-relaxed text-cream-100/65">
                  {step.desc}
                </p>
              </div>
            </motion.div>
          ))}
        </div>

        {/* STACK — tampilan mobile & tablet */}
        <div className="flex flex-col gap-4 lg:hidden">
          {steps.map((step, i) => (
            <motion.div
              key={step.n}
              initial={{ opacity: 0, x: -20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true, margin: "-60px" }}
              transition={{ duration: 0.5, delay: i * 0.1 }}
              className="flex gap-4 rounded-2xl bg-cream-100/[0.06] p-5 ring-1 ring-cream-100/10"
            >
              <div className="flex shrink-0 flex-col items-center">
                <div className="grid h-11 w-11 place-items-center rounded-full bg-gold-500/15">
                  <step.icon size={20} className="text-gold-300" />
                </div>
                {i < steps.length - 1 && (
                  <div className="mt-2 h-full w-px flex-1 bg-cream-100/15" />
                )}
              </div>
              <div className="pb-2">
                <span className="text-[11px] font-bold tracking-widest text-gold-300/80">
                  {step.n}
                </span>
                <h3 className="text-base font-bold text-cream-100">
                  {step.title}
                </h3>
                <p className="mt-1 text-sm leading-relaxed text-cream-100/65">
                  {step.desc}
                </p>
              </div>
            </motion.div>
          ))}
          <div className="flex items-center gap-2 pl-1 text-xs font-medium text-gold-300/70">
            <Sprout size={14} />
            Siklus kembali berulang dari langkah 01 — tanpa akhir.
          </div>
        </div>
      </div>
    </section>
  );
}
