import { Droplet, Instagram, Mail, MessageCircle } from "lucide-react";

export default function Footer() {
  return (
    <footer className="bg-deep-900 bg-noise pt-16 pb-8 text-cream-100/70">
      <div className="mx-auto max-w-7xl px-6 lg:px-10">
        <div className="grid gap-10 sm:grid-cols-2 lg:grid-cols-4">
          <div className="lg:col-span-2">
            <div className="flex items-center gap-2">
              <span className="grid h-9 w-9 place-items-center rounded-full bg-cream-100/10">
                <Droplet size={18} className="text-gold-300" />
              </span>
              <span className="text-lg font-extrabold text-cream-100">
                Echowash
              </span>
            </div>
            <p className="mt-4 max-w-sm text-sm leading-relaxed">
              Sabun cuci piring dari daur ulang minyak jelantah dan ekstrak
              buah lerak. Dibuat untuk dapur yang bersih dan bumi yang lebih
              sehat.
            </p>
          </div>

          <div>
            <h4 className="text-sm font-semibold text-cream-100">Jelajahi</h4>
            <ul className="mt-4 space-y-3 text-sm">
              <li>
                <a href="#solusi" className="hover:text-gold-300">
                  Masalah & Solusi
                </a>
              </li>
              <li>
                <a href="#bahan" className="hover:text-gold-300">
                  Bahan Alami
                </a>
              </li>
              <li>
                <a href="#sirkular" className="hover:text-gold-300">
                  Ekonomi Sirkular
                </a>
              </li>
            </ul>
          </div>

          <div>
            <h4 className="text-sm font-semibold text-cream-100">Terhubung</h4>
            <div className="mt-4 flex gap-3">
              <a
                href="https://www.instagram.com/ecowash_id?stkn=MXd2NHl3N3U5azE2eA%3D%3D"
                target="_blank"
                rel="noopener noreferrer"
                aria-label="Instagram Echowash"
                className="grid h-10 w-10 place-items-center rounded-full bg-cream-100/10 transition-colors hover:bg-gold-500 hover:text-deep-900"
              >
                <Instagram size={18} />
              </a>
              <a
                href="#"
                aria-label="WhatsApp Echowash"
                className="grid h-10 w-10 place-items-center rounded-full bg-cream-100/10 transition-colors hover:bg-gold-500 hover:text-deep-900"
              >
                <MessageCircle size={18} />
              </a>
              <a
                href="#"
                aria-label="Email Echowash"
                className="grid h-10 w-10 place-items-center rounded-full bg-cream-100/10 transition-colors hover:bg-gold-500 hover:text-deep-900"
              >
                <Mail size={18} />
              </a>
            </div>
          </div>
        </div>

        <div className="mt-14 flex flex-col gap-3 border-t border-cream-100/10 pt-6 text-xs sm:flex-row sm:items-center sm:justify-between">
          <p>© {new Date().getFullYear()} Echowash. Dari limbah, untuk bumi.</p>
          <p>Diracik dengan hati di Indonesia 🌿</p>
        </div>
      </div>
    </footer>
  );
}
