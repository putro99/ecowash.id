"use client";

import { motion } from "framer-motion";
import { ArrowRight, Leaf, Recycle, ShieldCheck } from "lucide-react";

const badges = [
  { icon: Recycle, label: "Dari Minyak Jelantah Daur Ulang" },
  { icon: Leaf, label: "Ekstrak Lerak 100% Alami" },
  { icon: ShieldCheck, label: "Aman Bagi Perairan" },
];

export default function Hero() {
  return (
    <section className="relative min-h-screen w-full overflow-hidden bg-deep-900 bg-noise">
      {/* Video reveal produk sebagai lapisan visual utama hero */}
      <div className="absolute inset-0">
        <video
          autoPlay
          muted
          loop
          playsInline
          poster="/images/product-hero.jpg"
          className="absolute inset-0 h-full w-full object-cover opacity-90"
        >
          <source src="/videos/hero-reveal.webm" type="video/webm" />
          <source src="/videos/hero-reveal.mp4" type="video/mp4" />
        </video>
        {/* Gradasi agar teks tetap terbaca di atas video */}
        <div className="absolute inset-0 bg-gradient-to-t from-deep-900 via-deep-900/70 to-deep-900/30" />
        <div className="absolute inset-0 bg-gradient-to-r from-deep-900/90 via-deep-900/30 to-transparent" />
      </div>

      <div className="relative z-10 mx-auto flex min-h-screen max-w-7xl flex-col justify-center px-6 pt-24 lg:px-10">
        <motion.span
          initial={{ opacity: 0, y: 12 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="mb-6 inline-flex w-fit items-center gap-2 rounded-full border border-cream-100/20 bg-cream-100/10 px-4 py-1.5 text-xs font-semibold uppercase tracking-widest text-gold-300 backdrop-blur-sm"
        >
          Gerakan Dapur Sirkular
        </motion.span>

        <motion.h1
          initial={{ opacity: 0, y: 24 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, delay: 0.1 }}
          className="text-balance max-w-3xl text-5xl font-extrabold leading-[1.05] tracking-tight text-cream-100 sm:text-6xl lg:text-7xl"
        >
          Bersih Maksimal,{" "}
          <span className="text-gold-300">Rawat Bumi Kita</span>
        </motion.h1>

        <motion.p
          initial={{ opacity: 0, y: 24 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, delay: 0.22 }}
          className="text-balance mt-6 max-w-xl text-lg leading-relaxed text-cream-100/85 sm:text-xl"
        >
          Echowash mengubah limbah minyak jelantah dan ekstrak buah lerak
          menjadi sabun cuci piring yang ampuh melawan lemak, lembut di
          tangan, dan aman kembali ke alam.
        </motion.p>

        <motion.div
          initial={{ opacity: 0, y: 24 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, delay: 0.34 }}
          className="mt-10 flex flex-wrap items-center gap-4"
        >
          <a
            href="#cta"
            className="group inline-flex items-center gap-2 rounded-full bg-gold-500 px-7 py-4 text-base font-semibold text-deep-900 shadow-lg shadow-gold-900/20 transition-all hover:bg-gold-300 hover:shadow-xl"
          >
            Pesan Echowash Sekarang
            <ArrowRight
              size={18}
              className="transition-transform group-hover:translate-x-1"
            />
          </a>
          <a
            href="#sirkular"
            className="inline-flex items-center gap-2 rounded-full border border-cream-100/30 px-7 py-4 text-base font-semibold text-cream-100 transition-colors hover:bg-cream-100/10"
          >
            Lihat Prosesnya
          </a>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 24 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, delay: 0.46 }}
          className="mt-14 flex flex-wrap gap-x-8 gap-y-4"
        >
          {badges.map(({ icon: Icon, label }) => (
            <div key={label} className="flex items-center gap-2.5">
              <Icon size={18} className="text-gold-300 shrink-0" />
              <span className="text-sm font-medium text-cream-100/80">
                {label}
              </span>
            </div>
          ))}
        </motion.div>
      </div>

      {/* Indikator scroll */}
      <motion.div
        animate={{ y: [0, 10, 0] }}
        transition={{ duration: 2, repeat: Infinity, ease: "easeInOut" }}
        className="absolute bottom-8 left-1/2 z-10 -translate-x-1/2 text-cream-100/60"
      >
        <div className="h-9 w-5 rounded-full border-2 border-cream-100/40 p-1">
          <div className="h-1.5 w-1.5 rounded-full bg-gold-300" />
        </div>
      </motion.div>
    </section>
  );
}
