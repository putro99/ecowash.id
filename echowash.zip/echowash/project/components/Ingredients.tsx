"use client";

import { motion } from "framer-motion";
import { Leaf, Recycle } from "lucide-react";

export default function Ingredients() {
  return (
    <section id="bahan" className="bg-sage-50 py-24 sm:py-32">
      <div className="mx-auto max-w-7xl px-6 lg:px-10">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-100px" }}
          transition={{ duration: 0.6 }}
          className="mx-auto mb-16 max-w-2xl text-center"
        >
          <span className="text-xs font-semibold uppercase tracking-widest text-gold-700">
            Dua Bahan, Satu Tujuan
          </span>
          <h2 className="text-balance mt-4 text-3xl font-extrabold tracking-tight text-sage-900 sm:text-4xl">
            Diracik dari Limbah dan Kearifan Lokal
          </h2>
        </motion.div>

        <div className="grid grid-cols-1 gap-6 lg:grid-cols-5">
          {/* Card 1 — Minyak Jelantah, lebih besar */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: "-80px" }}
            transition={{ duration: 0.6 }}
            className="group relative overflow-hidden rounded-3xl bg-deep-900 bg-noise p-9 text-cream-100 sm:p-11 lg:col-span-3"
          >
            <div className="pointer-events-none absolute -right-10 -top-10 h-56 w-56 rounded-full bg-gold-500/10 blur-2xl transition-transform duration-700 group-hover:scale-125" />
            <div className="relative">
              <div className="mb-8 grid h-14 w-14 place-items-center rounded-2xl bg-gold-500/15">
                <Recycle size={26} className="text-gold-300" />
              </div>
              <h3 className="text-2xl font-bold sm:text-3xl">
                Minyak Jelantah, Disulap Jadi Berkah
              </h3>
              <p className="mt-4 max-w-md leading-relaxed text-cream-100/75">
                Kami mengumpulkan minyak jelantah dari dapur rumah tangga dan
                UMKM, lalu menyaring dan memurnikannya melalui proses
                terkontrol hingga bebas dari residu kotoran. Tak ada yang
                terbuang — limbah pun berubah nilai menjadi bahan dasar
                pembersih berkualitas.
              </p>
              <div className="mt-8 flex flex-wrap gap-2">
                {["Didaur Ulang", "Dimurnikan", "Nol Limbah"].map((tag) => (
                  <span
                    key={tag}
                    className="rounded-full border border-cream-100/20 px-3.5 py-1.5 text-xs font-medium text-cream-100/80"
                  >
                    {tag}
                  </span>
                ))}
              </div>
            </div>
          </motion.div>

          {/* Card 2 — Ekstrak Lerak */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: "-80px" }}
            transition={{ duration: 0.6, delay: 0.12 }}
            className="group relative overflow-hidden rounded-3xl bg-lerak-700 p-9 text-cream-100 sm:p-11 lg:col-span-2"
          >
            <div className="pointer-events-none absolute -bottom-10 -left-10 h-48 w-48 rounded-full bg-sage-400/15 blur-2xl transition-transform duration-700 group-hover:scale-125" />
            <div className="relative">
              <div className="mb-8 grid h-14 w-14 place-items-center rounded-2xl bg-sage-400/15">
                <Leaf size={26} className="text-sage-300" />
              </div>
              <h3 className="text-2xl font-bold">
                Ekstrak Lerak, Warisan Nusantara
              </h3>
              <p className="mt-4 leading-relaxed text-cream-100/75">
                Buah lerak mengandung saponin alami — busa pembersih yang
                telah dipercaya masyarakat Indonesia turun-temurun. Lembut di
                tangan, bebas bahan kimia keras, namun tetap tuntas
                mengangkat lemak membandel.
              </p>
              <div className="mt-8 flex flex-wrap gap-2">
                {["Saponin Alami", "Lembut di Tangan"].map((tag) => (
                  <span
                    key={tag}
                    className="rounded-full border border-cream-100/20 px-3.5 py-1.5 text-xs font-medium text-cream-100/80"
                  >
                    {tag}
                  </span>
                ))}
              </div>
            </div>
          </motion.div>

          {/* Strip statistik bento */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: "-80px" }}
            transition={{ duration: 0.6, delay: 0.24 }}
            className="flex flex-col items-center justify-center gap-2 rounded-3xl bg-gold-500 px-9 py-10 text-center text-deep-900 sm:flex-row sm:justify-between sm:gap-6 sm:px-11 lg:col-span-5"
          >
            <p className="text-2xl font-extrabold tracking-tight sm:text-3xl">
              2 Bahan Alami. 1 Misi Besar.
            </p>
            <p className="max-w-md text-sm font-medium text-deep-900/80 sm:text-right">
              Tanpa fosfat, tanpa pewarna berbahaya — nol kompromi untuk
              kebersihan dapurmu dan kesehatan bumi.
            </p>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
