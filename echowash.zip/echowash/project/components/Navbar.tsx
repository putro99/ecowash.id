"use client";

import { useEffect, useState } from "react";
import { motion } from "framer-motion";
import { Droplet, Menu, X } from "lucide-react";

const links = [
  { label: "Masalah & Solusi", href: "#solusi" },
  { label: "Bahan Alami", href: "#bahan" },
  { label: "Ekonomi Sirkular", href: "#sirkular" },
];

export default function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 24);
    window.addEventListener("scroll", onScroll);
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <motion.header
      initial={{ y: -80, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      transition={{ duration: 0.6, ease: "easeOut" }}
      className={`fixed top-0 inset-x-0 z-50 transition-colors duration-300 ${
        scrolled
          ? "bg-cream-100/90 backdrop-blur-md shadow-sm"
          : "bg-transparent"
      }`}
    >
      <nav className="mx-auto max-w-7xl px-6 lg:px-10 flex items-center justify-between h-20">
        <a href="#" className="flex items-center gap-2 group">
          <span
            className={`grid place-items-center w-9 h-9 rounded-full transition-colors ${
              scrolled ? "bg-sage-600" : "bg-cream-100/90"
            }`}
          >
            <Droplet
              className={scrolled ? "text-cream" : "text-sage-700"}
              size={18}
              strokeWidth={2.5}
            />
          </span>
          <span
            className={`font-extrabold text-lg tracking-tight ${
              scrolled ? "text-sage-800" : "text-cream-100"
            }`}
          >
            Echowash
          </span>
        </a>

        <div className="hidden md:flex items-center gap-9">
          {links.map((link) => (
            <a
              key={link.href}
              href={link.href}
              className={`text-sm font-medium transition-colors hover:text-gold-500 ${
                scrolled ? "text-sage-700" : "text-cream-100/90"
              }`}
            >
              {link.label}
            </a>
          ))}
        </div>

        <div className="hidden md:block">
          <a
            href="#cta"
            className="inline-flex items-center rounded-full bg-sage-600 px-5 py-2.5 text-sm font-semibold text-cream-100 shadow-sm transition-all hover:bg-sage-700 hover:shadow-md"
          >
            Beli Sekarang
          </a>
        </div>

        <button
          aria-label="Buka menu"
          onClick={() => setOpen(!open)}
          className={`md:hidden p-2 rounded-lg ${
            scrolled ? "text-sage-800" : "text-cream-100"
          }`}
        >
          {open ? <X size={24} /> : <Menu size={24} />}
        </button>
      </nav>

      {open && (
        <motion.div
          initial={{ height: 0, opacity: 0 }}
          animate={{ height: "auto", opacity: 1 }}
          exit={{ height: 0, opacity: 0 }}
          className="md:hidden bg-cream-100 border-t border-sage-200 px-6 py-6 flex flex-col gap-5"
        >
          {links.map((link) => (
            <a
              key={link.href}
              href={link.href}
              onClick={() => setOpen(false)}
              className="text-sage-800 font-medium"
            >
              {link.label}
            </a>
          ))}
          <a
            href="#cta"
            onClick={() => setOpen(false)}
            className="inline-flex items-center justify-center rounded-full bg-sage-600 px-5 py-3 text-sm font-semibold text-cream-100"
          >
            Beli Sekarang
          </a>
        </motion.div>
      )}
    </motion.header>
  );
}
