"use client";

import { motion } from "framer-motion";
import { ArrowRight, Droplets, Sparkles } from "lucide-react";

export default function ProblemSolution() {
  return (
    <section id="solusi" className="relative bg-cream py-24 sm:py-32">
      <div className="mx-auto max-w-7xl px-6 lg:px-10">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-100px" }}
          transition={{ duration: 0.6 }}
          className="mx-auto mb-16 max-w-2xl text-center"
        >
          <span className="text-xs font-semibold uppercase tracking-widest text-gold-700">
            Kenapa Ini Penting
          </span>
          <h2 className="text-balance mt-4 text-3xl font-extrabold tracking-tight text-sage-900 sm:text-4xl">
            Limbah Dapur Kita, Ancaman Diam untuk Air Bersih
          </h2>
        </motion.div>

        <div className="relative grid gap-6 lg:grid-cols-[1fr_auto_1fr] lg:items-stretch">
          {/* Kartu masalah */}
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true, margin: "-100px" }}
            transition={{ duration: 0.7 }}
            className="rounded-3xl bg-deep-900 bg-noise p-9 text-cream-100 sm:p-11"
          >
            <div className="mb-6 grid h-12 w-12 place-items-center rounded-full bg-cream-100/10">
              <Droplets size={22} className="text-cream-100/70" />
            </div>
            <h3 className="text-2xl font-bold">Minyak Jelantah yang Dibuang</h3>
            <p className="mt-4 leading-relaxed text-cream-100/75">
              Setiap hari, minyak jelantah dari dapur rumah tangga dan UMKM
              dituang begitu saja ke saluran air. Minyak ini mengapung,
              menyumbat aliran, dan menghalangi oksigen masuk ke perairan —
              perlahan meracuni ekosistem sungai yang menjadi sumber
              kehidupan banyak makhluk.
            </p>
            <p className="mt-4 leading-relaxed text-cream-100/75">
              Ditambah lagi, deterjen konvensional dengan bahan kimia keras
              memperparah pencemaran ini setiap kali kita mencuci piring.
            </p>
          </motion.div>

          {/* Panah transformasi */}
          <div className="flex items-center justify-center py-2 lg:py-0">
            <motion.div
              initial={{ opacity: 0, scale: 0.6 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: 0.3 }}
              className="grid h-14 w-14 place-items-center rounded-full bg-gold-500 text-deep-900 shadow-lg lg:rotate-0 rotate-90"
            >
              <ArrowRight size={22} strokeWidth={2.5} />
            </motion.div>
          </div>

          {/* Kartu solusi */}
          <motion.div
            initial={{ opacity: 0, x: 30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true, margin: "-100px" }}
            transition={{ duration: 0.7, delay: 0.15 }}
            className="rounded-3xl bg-sage-600 p-9 text-cream-100 sm:p-11"
          >
            <div className="mb-6 grid h-12 w-12 place-items-center rounded-full bg-cream-100/15">
              <Sparkles size={22} className="text-gold-300" />
            </div>
            <h3 className="text-2xl font-bold">Echowash Hadir Sebagai Jawaban</h3>
            <p className="mt-4 leading-relaxed text-cream-100/90">
              Kami menjemput minyak jelantah sebelum sempat mencemari, lalu
              memurnikannya dan memadukannya dengan ekstrak buah lerak —
              pembersih alami yang telah dipercaya turun-temurun di
              Nusantara.
            </p>
            <p className="mt-4 leading-relaxed text-cream-100/90">
              Hasilnya: sabun cuci piring yang berbusa lembut, ampuh
              mengangkat lemak, lembut di tangan, dan terurai alami tanpa
              meninggalkan jejak beracun di air.
            </p>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
