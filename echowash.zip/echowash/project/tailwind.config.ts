import type { Config } from "tailwindcss";

const config: Config = {
  content: [
    "./app/**/*.{ts,tsx}",
    "./components/**/*.{ts,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        // Hijau sage — identitas "ramah lingkungan" utama
        sage: {
          50: "#F3F6F1",
          100: "#E4EBDF",
          200: "#C8D8BE",
          300: "#A6C098",
          400: "#7E9F71",
          500: "#5C7F50", // sage utama
          600: "#496640",
          700: "#3A5133",
          800: "#2B3D26",
          900: "#1D2919",
        },
        // Krem / putih bersih — representasi busa & kebersihan
        cream: {
          DEFAULT: "#F8F4E9",
          100: "#FFFDF9",
          200: "#F1E9D6",
        },
        // Kuning keemasan — representasi minyak yang dimurnikan
        gold: {
          DEFAULT: "#C9993E",
          300: "#E0C077",
          500: "#C9993E",
          700: "#9C742A",
        },
        // Cokelat lerak — representasi buah lerak & kehangatan tradisional
        lerak: {
          DEFAULT: "#5C3A22",
          400: "#7A5236",
          700: "#3E2515",
        },
        // Teal dalam — dipakai di Hero agar menyatu dengan video produk
        deep: {
          DEFAULT: "#20413F",
          800: "#16302E",
          900: "#0F2321",
        },
      },
      fontFamily: {
        sans: ["var(--font-jakarta)", "sans-serif"],
      },
      keyframes: {
        float: {
          "0%, 100%": { transform: "translateY(0px)" },
          "50%": { transform: "translateY(-14px)" },
        },
        "spin-slow": {
          from: { transform: "rotate(0deg)" },
          to: { transform: "rotate(360deg)" },
        },
      },
      animation: {
        float: "float 6s ease-in-out infinite",
        "spin-slow": "spin-slow 40s linear infinite",
      },
    },
  },
  plugins: [],
};
export default config;
